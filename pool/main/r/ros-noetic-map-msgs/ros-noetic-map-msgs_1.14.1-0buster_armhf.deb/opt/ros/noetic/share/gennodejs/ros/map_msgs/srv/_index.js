
"use strict";

let GetPointMapROI = require('./GetPointMapROI.js')
let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let GetPointMap = require('./GetPointMap.js')
let GetMapROI = require('./GetMapROI.js')
let SaveMap = require('./SaveMap.js')
let SetMapProjections = require('./SetMapProjections.js')

module.exports = {
  GetPointMapROI: GetPointMapROI,
  ProjectedMapsInfo: ProjectedMapsInfo,
  GetPointMap: GetPointMap,
  GetMapROI: GetMapROI,
  SaveMap: SaveMap,
  SetMapProjections: SetMapProjections,
};
