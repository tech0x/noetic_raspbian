
"use strict";

let TestFeedback = require('./TestFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestResult = require('./TestResult.js');
let TestRequestResult = require('./TestRequestResult.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestActionResult = require('./TestActionResult.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestAction = require('./TestAction.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');

module.exports = {
  TestFeedback: TestFeedback,
  TestActionGoal: TestActionGoal,
  TwoIntsActionResult: TwoIntsActionResult,
  TwoIntsResult: TwoIntsResult,
  TestRequestFeedback: TestRequestFeedback,
  TestResult: TestResult,
  TestRequestResult: TestRequestResult,
  TestRequestAction: TestRequestAction,
  TestRequestGoal: TestRequestGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TwoIntsAction: TwoIntsAction,
  TestRequestActionResult: TestRequestActionResult,
  TestRequestActionGoal: TestRequestActionGoal,
  TestActionResult: TestActionResult,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestActionFeedback: TestActionFeedback,
  TestAction: TestAction,
  TestGoal: TestGoal,
  TwoIntsGoal: TwoIntsGoal,
};
