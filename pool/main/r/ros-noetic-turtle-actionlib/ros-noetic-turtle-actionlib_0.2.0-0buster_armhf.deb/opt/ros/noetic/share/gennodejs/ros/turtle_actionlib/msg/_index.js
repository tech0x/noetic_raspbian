
"use strict";

let Velocity = require('./Velocity.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeFeedback = require('./ShapeFeedback.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeResult = require('./ShapeResult.js');

module.exports = {
  Velocity: Velocity,
  ShapeActionResult: ShapeActionResult,
  ShapeAction: ShapeAction,
  ShapeFeedback: ShapeFeedback,
  ShapeGoal: ShapeGoal,
  ShapeActionGoal: ShapeActionGoal,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeResult: ShapeResult,
};
