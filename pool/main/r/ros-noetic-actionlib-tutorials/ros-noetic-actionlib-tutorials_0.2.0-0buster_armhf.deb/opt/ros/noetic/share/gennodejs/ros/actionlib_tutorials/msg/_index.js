
"use strict";

let AveragingAction = require('./AveragingAction.js');
let FibonacciFeedback = require('./FibonacciFeedback.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let AveragingResult = require('./AveragingResult.js');
let FibonacciResult = require('./FibonacciResult.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let AveragingGoal = require('./AveragingGoal.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let AveragingActionResult = require('./AveragingActionResult.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let FibonacciAction = require('./FibonacciAction.js');
let FibonacciGoal = require('./FibonacciGoal.js');

module.exports = {
  AveragingAction: AveragingAction,
  FibonacciFeedback: FibonacciFeedback,
  AveragingActionGoal: AveragingActionGoal,
  FibonacciActionResult: FibonacciActionResult,
  AveragingActionFeedback: AveragingActionFeedback,
  AveragingResult: AveragingResult,
  FibonacciResult: FibonacciResult,
  AveragingFeedback: AveragingFeedback,
  AveragingGoal: AveragingGoal,
  FibonacciActionFeedback: FibonacciActionFeedback,
  AveragingActionResult: AveragingActionResult,
  FibonacciActionGoal: FibonacciActionGoal,
  FibonacciAction: FibonacciAction,
  FibonacciGoal: FibonacciGoal,
};
